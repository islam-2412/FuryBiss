# -*- coding: utf-8 -*-
# FuryBiss loader - keep this file visible for Enigma2 Plugin Browser.
# Real code is protected inside plugin_core.so

try:
    from .plugin_core import *
except Exception:
    from plugin_core import *
